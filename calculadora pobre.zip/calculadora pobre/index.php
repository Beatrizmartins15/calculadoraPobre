<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="icon" type="image/png" href="https://icones.pro/wp-content/uploads/2021/06/icone-de-la-calculatrice-rose.png"/>
    <title>Calculadora Avançada</title>
</head>
<body>
    <a class="btn btn-warning" href="/">Home</a>
    <a class="btn btn-primary" href="?page=tabuada">Tabuada</a>
    <a class="btn btn-primary" href="?page=1">Cálculo de Imc</a>
    <a class="btn btn-primary" href="?page=2">Custo da Viagem</a>
    <a class="btn btn-primary" href="?page=3">Página 3</a>
    
    <?php
        http://materialaulapw3.local/?page
        if(isset($_GET['page'])){
            $page = $_GET['page'];
            switch($page){
                case '1':
                    require_once './page/CalculoImc.php';
                    break;
                case '2':
                    require_once './page/CusViagem.php';
                    break;
                case '3':
                    require_once './page/page3.php';
                    break;
                case 'tabuada':
                    require_once './page/tabuada.php';
                    break;
                default:
                    require_once './page/page404.php';
            }
        }
        else{
            echo 'Não foi';
        }
        // var_dump($_GET);

        
    ?>
</body>
</html>
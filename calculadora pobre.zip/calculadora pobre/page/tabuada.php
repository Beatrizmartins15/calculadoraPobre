<h1>Tabuada</h1>
<form method="post">
<input type="number" name="tabuada" placeholder="tabuada">
<input type="number" name="inicio" placeholder="inicio">
<input type="submit" value="Enviar">
</form>

 <?php
 if ( isset($_POST['tabuada'])&&($_POST['inicio']))
for($id = $_POST['inicio']; $id <= $_POST['tabuada']; $id++){
    if($_POST['inicio'] == 0){
        for($id = 0; $id <= $_POST['tabuada']; $id++){
            echo "<h3> $id * ".$_POST['tabuada']." = ".$_POST['tabuada'] * $id."</h5>";
        }
    }
            echo "<h3> $id * ".$_POST['tabuada']." = ".$_POST['tabuada'] * $id."</h5>";
        }
?>
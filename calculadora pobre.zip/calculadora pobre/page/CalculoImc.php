<h1>Cálculo IMC</h1>

<form method="post">
<input type="number" name="peso" placeholder="peso">
<input type="number" name="altura" placeholder="altura">
<input type="submit" value="Enviar">

<?php 
if ( isset($_POST['peso'])&&($_POST['altura'])){
$peso = $_POST['peso'];
$altura = $_POST['altura'] / 100;
$imc = $peso/$altura ** 2;

if ($imc <=20){

    echo " A pessoa está abaixo do peso <br> " ;
}

if ($imc >20 and $imc<=25) {

    echo " A pessoa está com peso normal <br> " ;
}

if($imc >25 and $imc <=30 ) {

    echo " A pessoa está acima do peso <br> " ;

}

if ($imc >30 ){
    echo " A pessoa está com obesidade mórbida <br> " ;
}
}?>
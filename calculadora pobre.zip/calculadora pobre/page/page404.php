<h1>Error 404 (page not found)</h1>
<img src="https://i.pinimg.com/originals/2c/54/c8/2c54c885bec02dc903a6904c68fbc0b8.png" alt="Dino Google">